import data from './data'
import users from './users'

const settings = {
    data: Object.assign(data, data),
    users: Object.assign(users, users),
}

export default settings