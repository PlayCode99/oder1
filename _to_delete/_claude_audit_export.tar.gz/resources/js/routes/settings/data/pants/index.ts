import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:114
* @route '/settings/data/pants'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/settings/data/pants',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:114
* @route '/settings/data/pants'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:114
* @route '/settings/data/pants'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:114
* @route '/settings/data/pants'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:114
* @route '/settings/data/pants'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:114
* @route '/settings/data/pants'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:114
* @route '/settings/data/pants'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\ShirtCatalogController::catalog
* @see app/Http/Controllers/ShirtCatalogController.php:124
* @route '/settings/data/pants/catalog/{catalog}'
*/
export const catalog = (args: { catalog: string | number } | [catalog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: catalog.url(args, options),
    method: 'get',
})

catalog.definition = {
    methods: ["get","head"],
    url: '/settings/data/pants/catalog/{catalog}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShirtCatalogController::catalog
* @see app/Http/Controllers/ShirtCatalogController.php:124
* @route '/settings/data/pants/catalog/{catalog}'
*/
catalog.url = (args: { catalog: string | number } | [catalog: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { catalog: args }
    }

    if (Array.isArray(args)) {
        args = {
            catalog: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        catalog: args.catalog,
    }

    return catalog.definition.url
            .replace('{catalog}', parsedArgs.catalog.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShirtCatalogController::catalog
* @see app/Http/Controllers/ShirtCatalogController.php:124
* @route '/settings/data/pants/catalog/{catalog}'
*/
catalog.get = (args: { catalog: string | number } | [catalog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: catalog.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::catalog
* @see app/Http/Controllers/ShirtCatalogController.php:124
* @route '/settings/data/pants/catalog/{catalog}'
*/
catalog.head = (args: { catalog: string | number } | [catalog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: catalog.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::catalog
* @see app/Http/Controllers/ShirtCatalogController.php:124
* @route '/settings/data/pants/catalog/{catalog}'
*/
const catalogForm = (args: { catalog: string | number } | [catalog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: catalog.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::catalog
* @see app/Http/Controllers/ShirtCatalogController.php:124
* @route '/settings/data/pants/catalog/{catalog}'
*/
catalogForm.get = (args: { catalog: string | number } | [catalog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: catalog.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::catalog
* @see app/Http/Controllers/ShirtCatalogController.php:124
* @route '/settings/data/pants/catalog/{catalog}'
*/
catalogForm.head = (args: { catalog: string | number } | [catalog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: catalog.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

catalog.form = catalogForm

const pants = {
    index: Object.assign(index, index),
    catalog: Object.assign(catalog, catalog),
}

export default pants