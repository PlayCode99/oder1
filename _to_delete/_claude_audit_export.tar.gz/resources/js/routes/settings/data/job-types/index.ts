import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:177
* @route '/settings/data/job-types'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/settings/data/job-types',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:177
* @route '/settings/data/job-types'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:177
* @route '/settings/data/job-types'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:177
* @route '/settings/data/job-types'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:177
* @route '/settings/data/job-types'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:177
* @route '/settings/data/job-types'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:177
* @route '/settings/data/job-types'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const jobTypes = {
    index: Object.assign(index, index),
}

export default jobTypes