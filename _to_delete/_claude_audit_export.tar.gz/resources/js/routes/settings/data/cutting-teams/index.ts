import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::index
* @see app/Http/Controllers/Settings/CuttingTeamController.php:15
* @route '/settings/data/cutting-teams'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/settings/data/cutting-teams',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::index
* @see app/Http/Controllers/Settings/CuttingTeamController.php:15
* @route '/settings/data/cutting-teams'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::index
* @see app/Http/Controllers/Settings/CuttingTeamController.php:15
* @route '/settings/data/cutting-teams'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::index
* @see app/Http/Controllers/Settings/CuttingTeamController.php:15
* @route '/settings/data/cutting-teams'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::index
* @see app/Http/Controllers/Settings/CuttingTeamController.php:15
* @route '/settings/data/cutting-teams'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::index
* @see app/Http/Controllers/Settings/CuttingTeamController.php:15
* @route '/settings/data/cutting-teams'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::index
* @see app/Http/Controllers/Settings/CuttingTeamController.php:15
* @route '/settings/data/cutting-teams'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::store
* @see app/Http/Controllers/Settings/CuttingTeamController.php:22
* @route '/settings/data/cutting-teams'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/settings/data/cutting-teams',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::store
* @see app/Http/Controllers/Settings/CuttingTeamController.php:22
* @route '/settings/data/cutting-teams'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::store
* @see app/Http/Controllers/Settings/CuttingTeamController.php:22
* @route '/settings/data/cutting-teams'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::store
* @see app/Http/Controllers/Settings/CuttingTeamController.php:22
* @route '/settings/data/cutting-teams'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::store
* @see app/Http/Controllers/Settings/CuttingTeamController.php:22
* @route '/settings/data/cutting-teams'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::update
* @see app/Http/Controllers/Settings/CuttingTeamController.php:37
* @route '/settings/data/cutting-teams/{cuttingTeam}'
*/
export const update = (args: { cuttingTeam: number | { id: number } } | [cuttingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/settings/data/cutting-teams/{cuttingTeam}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::update
* @see app/Http/Controllers/Settings/CuttingTeamController.php:37
* @route '/settings/data/cutting-teams/{cuttingTeam}'
*/
update.url = (args: { cuttingTeam: number | { id: number } } | [cuttingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cuttingTeam: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { cuttingTeam: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            cuttingTeam: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        cuttingTeam: typeof args.cuttingTeam === 'object'
        ? args.cuttingTeam.id
        : args.cuttingTeam,
    }

    return update.definition.url
            .replace('{cuttingTeam}', parsedArgs.cuttingTeam.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::update
* @see app/Http/Controllers/Settings/CuttingTeamController.php:37
* @route '/settings/data/cutting-teams/{cuttingTeam}'
*/
update.put = (args: { cuttingTeam: number | { id: number } } | [cuttingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::update
* @see app/Http/Controllers/Settings/CuttingTeamController.php:37
* @route '/settings/data/cutting-teams/{cuttingTeam}'
*/
const updateForm = (args: { cuttingTeam: number | { id: number } } | [cuttingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::update
* @see app/Http/Controllers/Settings/CuttingTeamController.php:37
* @route '/settings/data/cutting-teams/{cuttingTeam}'
*/
updateForm.put = (args: { cuttingTeam: number | { id: number } } | [cuttingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::destroy
* @see app/Http/Controllers/Settings/CuttingTeamController.php:57
* @route '/settings/data/cutting-teams/{cuttingTeam}'
*/
export const destroy = (args: { cuttingTeam: number | { id: number } } | [cuttingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/settings/data/cutting-teams/{cuttingTeam}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::destroy
* @see app/Http/Controllers/Settings/CuttingTeamController.php:57
* @route '/settings/data/cutting-teams/{cuttingTeam}'
*/
destroy.url = (args: { cuttingTeam: number | { id: number } } | [cuttingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cuttingTeam: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { cuttingTeam: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            cuttingTeam: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        cuttingTeam: typeof args.cuttingTeam === 'object'
        ? args.cuttingTeam.id
        : args.cuttingTeam,
    }

    return destroy.definition.url
            .replace('{cuttingTeam}', parsedArgs.cuttingTeam.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::destroy
* @see app/Http/Controllers/Settings/CuttingTeamController.php:57
* @route '/settings/data/cutting-teams/{cuttingTeam}'
*/
destroy.delete = (args: { cuttingTeam: number | { id: number } } | [cuttingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::destroy
* @see app/Http/Controllers/Settings/CuttingTeamController.php:57
* @route '/settings/data/cutting-teams/{cuttingTeam}'
*/
const destroyForm = (args: { cuttingTeam: number | { id: number } } | [cuttingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\CuttingTeamController::destroy
* @see app/Http/Controllers/Settings/CuttingTeamController.php:57
* @route '/settings/data/cutting-teams/{cuttingTeam}'
*/
destroyForm.delete = (args: { cuttingTeam: number | { id: number } } | [cuttingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const cuttingTeams = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default cuttingTeams