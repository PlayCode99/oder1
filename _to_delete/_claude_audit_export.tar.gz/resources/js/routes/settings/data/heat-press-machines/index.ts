import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::index
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:15
* @route '/settings/data/heat-press-machines'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/settings/data/heat-press-machines',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::index
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:15
* @route '/settings/data/heat-press-machines'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::index
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:15
* @route '/settings/data/heat-press-machines'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::index
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:15
* @route '/settings/data/heat-press-machines'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::index
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:15
* @route '/settings/data/heat-press-machines'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::index
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:15
* @route '/settings/data/heat-press-machines'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::index
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:15
* @route '/settings/data/heat-press-machines'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::store
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:22
* @route '/settings/data/heat-press-machines'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/settings/data/heat-press-machines',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::store
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:22
* @route '/settings/data/heat-press-machines'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::store
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:22
* @route '/settings/data/heat-press-machines'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::store
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:22
* @route '/settings/data/heat-press-machines'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::store
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:22
* @route '/settings/data/heat-press-machines'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::update
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:37
* @route '/settings/data/heat-press-machines/{heatPressMachine}'
*/
export const update = (args: { heatPressMachine: number | { id: number } } | [heatPressMachine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/settings/data/heat-press-machines/{heatPressMachine}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::update
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:37
* @route '/settings/data/heat-press-machines/{heatPressMachine}'
*/
update.url = (args: { heatPressMachine: number | { id: number } } | [heatPressMachine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { heatPressMachine: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { heatPressMachine: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            heatPressMachine: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        heatPressMachine: typeof args.heatPressMachine === 'object'
        ? args.heatPressMachine.id
        : args.heatPressMachine,
    }

    return update.definition.url
            .replace('{heatPressMachine}', parsedArgs.heatPressMachine.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::update
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:37
* @route '/settings/data/heat-press-machines/{heatPressMachine}'
*/
update.put = (args: { heatPressMachine: number | { id: number } } | [heatPressMachine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::update
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:37
* @route '/settings/data/heat-press-machines/{heatPressMachine}'
*/
const updateForm = (args: { heatPressMachine: number | { id: number } } | [heatPressMachine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::update
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:37
* @route '/settings/data/heat-press-machines/{heatPressMachine}'
*/
updateForm.put = (args: { heatPressMachine: number | { id: number } } | [heatPressMachine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::destroy
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:57
* @route '/settings/data/heat-press-machines/{heatPressMachine}'
*/
export const destroy = (args: { heatPressMachine: number | { id: number } } | [heatPressMachine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/settings/data/heat-press-machines/{heatPressMachine}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::destroy
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:57
* @route '/settings/data/heat-press-machines/{heatPressMachine}'
*/
destroy.url = (args: { heatPressMachine: number | { id: number } } | [heatPressMachine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { heatPressMachine: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { heatPressMachine: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            heatPressMachine: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        heatPressMachine: typeof args.heatPressMachine === 'object'
        ? args.heatPressMachine.id
        : args.heatPressMachine,
    }

    return destroy.definition.url
            .replace('{heatPressMachine}', parsedArgs.heatPressMachine.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::destroy
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:57
* @route '/settings/data/heat-press-machines/{heatPressMachine}'
*/
destroy.delete = (args: { heatPressMachine: number | { id: number } } | [heatPressMachine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::destroy
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:57
* @route '/settings/data/heat-press-machines/{heatPressMachine}'
*/
const destroyForm = (args: { heatPressMachine: number | { id: number } } | [heatPressMachine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\HeatPressMachineController::destroy
* @see app/Http/Controllers/Settings/HeatPressMachineController.php:57
* @route '/settings/data/heat-press-machines/{heatPressMachine}'
*/
destroyForm.delete = (args: { heatPressMachine: number | { id: number } } | [heatPressMachine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const heatPressMachines = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default heatPressMachines