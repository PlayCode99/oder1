import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ShirtCatalogController::sync
* @see app/Http/Controllers/ShirtCatalogController.php:182
* @route '/settings/data/catalog-items/sync'
*/
export const sync = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(options),
    method: 'post',
})

sync.definition = {
    methods: ["post"],
    url: '/settings/data/catalog-items/sync',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ShirtCatalogController::sync
* @see app/Http/Controllers/ShirtCatalogController.php:182
* @route '/settings/data/catalog-items/sync'
*/
sync.url = (options?: RouteQueryOptions) => {
    return sync.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShirtCatalogController::sync
* @see app/Http/Controllers/ShirtCatalogController.php:182
* @route '/settings/data/catalog-items/sync'
*/
sync.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::sync
* @see app/Http/Controllers/ShirtCatalogController.php:182
* @route '/settings/data/catalog-items/sync'
*/
const syncForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: sync.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::sync
* @see app/Http/Controllers/ShirtCatalogController.php:182
* @route '/settings/data/catalog-items/sync'
*/
syncForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: sync.url(options),
    method: 'post',
})

sync.form = syncForm

const catalogItems = {
    sync: Object.assign(sync, sync),
}

export default catalogItems