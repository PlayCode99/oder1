import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
import types907509 from './types'
/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:109
* @route '/settings/data/shirts'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/settings/data/shirts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:109
* @route '/settings/data/shirts'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:109
* @route '/settings/data/shirts'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:109
* @route '/settings/data/shirts'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:109
* @route '/settings/data/shirts'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:109
* @route '/settings/data/shirts'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::index
* @see app/Http/Controllers/ShirtCatalogController.php:109
* @route '/settings/data/shirts'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\ShirtDataManagementController::types
* @see app/Http/Controllers/ShirtDataManagementController.php:24
* @route '/settings/data/shirts/types'
*/
export const types = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: types.url(options),
    method: 'get',
})

types.definition = {
    methods: ["get","head"],
    url: '/settings/data/shirts/types',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShirtDataManagementController::types
* @see app/Http/Controllers/ShirtDataManagementController.php:24
* @route '/settings/data/shirts/types'
*/
types.url = (options?: RouteQueryOptions) => {
    return types.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShirtDataManagementController::types
* @see app/Http/Controllers/ShirtDataManagementController.php:24
* @route '/settings/data/shirts/types'
*/
types.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: types.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtDataManagementController::types
* @see app/Http/Controllers/ShirtDataManagementController.php:24
* @route '/settings/data/shirts/types'
*/
types.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: types.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ShirtDataManagementController::types
* @see app/Http/Controllers/ShirtDataManagementController.php:24
* @route '/settings/data/shirts/types'
*/
const typesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: types.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtDataManagementController::types
* @see app/Http/Controllers/ShirtDataManagementController.php:24
* @route '/settings/data/shirts/types'
*/
typesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: types.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtDataManagementController::types
* @see app/Http/Controllers/ShirtDataManagementController.php:24
* @route '/settings/data/shirts/types'
*/
typesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: types.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

types.form = typesForm

/**
* @see \App\Http\Controllers\ShirtCatalogController::patterns
* @see app/Http/Controllers/ShirtCatalogController.php:104
* @route '/settings/data/shirts/patterns'
*/
export const patterns = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: patterns.url(options),
    method: 'get',
})

patterns.definition = {
    methods: ["get","head"],
    url: '/settings/data/shirts/patterns',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShirtCatalogController::patterns
* @see app/Http/Controllers/ShirtCatalogController.php:104
* @route '/settings/data/shirts/patterns'
*/
patterns.url = (options?: RouteQueryOptions) => {
    return patterns.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShirtCatalogController::patterns
* @see app/Http/Controllers/ShirtCatalogController.php:104
* @route '/settings/data/shirts/patterns'
*/
patterns.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: patterns.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::patterns
* @see app/Http/Controllers/ShirtCatalogController.php:104
* @route '/settings/data/shirts/patterns'
*/
patterns.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: patterns.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::patterns
* @see app/Http/Controllers/ShirtCatalogController.php:104
* @route '/settings/data/shirts/patterns'
*/
const patternsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: patterns.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::patterns
* @see app/Http/Controllers/ShirtCatalogController.php:104
* @route '/settings/data/shirts/patterns'
*/
patternsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: patterns.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::patterns
* @see app/Http/Controllers/ShirtCatalogController.php:104
* @route '/settings/data/shirts/patterns'
*/
patternsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: patterns.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

patterns.form = patternsForm

/**
* @see \App\Http\Controllers\ShirtCatalogController::catalog
* @see app/Http/Controllers/ShirtCatalogController.php:119
* @route '/settings/data/shirts/catalog/{catalog}'
*/
export const catalog = (args: { catalog: string | number } | [catalog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: catalog.url(args, options),
    method: 'get',
})

catalog.definition = {
    methods: ["get","head"],
    url: '/settings/data/shirts/catalog/{catalog}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShirtCatalogController::catalog
* @see app/Http/Controllers/ShirtCatalogController.php:119
* @route '/settings/data/shirts/catalog/{catalog}'
*/
catalog.url = (args: { catalog: string | number } | [catalog: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { catalog: args }
    }

    if (Array.isArray(args)) {
        args = {
            catalog: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        catalog: args.catalog,
    }

    return catalog.definition.url
            .replace('{catalog}', parsedArgs.catalog.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShirtCatalogController::catalog
* @see app/Http/Controllers/ShirtCatalogController.php:119
* @route '/settings/data/shirts/catalog/{catalog}'
*/
catalog.get = (args: { catalog: string | number } | [catalog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: catalog.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::catalog
* @see app/Http/Controllers/ShirtCatalogController.php:119
* @route '/settings/data/shirts/catalog/{catalog}'
*/
catalog.head = (args: { catalog: string | number } | [catalog: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: catalog.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::catalog
* @see app/Http/Controllers/ShirtCatalogController.php:119
* @route '/settings/data/shirts/catalog/{catalog}'
*/
const catalogForm = (args: { catalog: string | number } | [catalog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: catalog.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::catalog
* @see app/Http/Controllers/ShirtCatalogController.php:119
* @route '/settings/data/shirts/catalog/{catalog}'
*/
catalogForm.get = (args: { catalog: string | number } | [catalog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: catalog.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::catalog
* @see app/Http/Controllers/ShirtCatalogController.php:119
* @route '/settings/data/shirts/catalog/{catalog}'
*/
catalogForm.head = (args: { catalog: string | number } | [catalog: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: catalog.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

catalog.form = catalogForm

const shirts = {
    index: Object.assign(index, index),
    types: Object.assign(types, types907509),
    patterns: Object.assign(patterns, patterns),
    catalog: Object.assign(catalog, catalog),
}

export default shirts