import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\ShirtDataManagementController::store
* @see app/Http/Controllers/ShirtDataManagementController.php:61
* @route '/settings/data/shirts/types'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/settings/data/shirts/types',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ShirtDataManagementController::store
* @see app/Http/Controllers/ShirtDataManagementController.php:61
* @route '/settings/data/shirts/types'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShirtDataManagementController::store
* @see app/Http/Controllers/ShirtDataManagementController.php:61
* @route '/settings/data/shirts/types'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ShirtDataManagementController::store
* @see app/Http/Controllers/ShirtDataManagementController.php:61
* @route '/settings/data/shirts/types'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ShirtDataManagementController::store
* @see app/Http/Controllers/ShirtDataManagementController.php:61
* @route '/settings/data/shirts/types'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\ShirtDataManagementController::update
* @see app/Http/Controllers/ShirtDataManagementController.php:73
* @route '/settings/data/shirts/types/{shirtType}'
*/
export const update = (args: { shirtType: number | { id: number } } | [shirtType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/settings/data/shirts/types/{shirtType}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ShirtDataManagementController::update
* @see app/Http/Controllers/ShirtDataManagementController.php:73
* @route '/settings/data/shirts/types/{shirtType}'
*/
update.url = (args: { shirtType: number | { id: number } } | [shirtType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { shirtType: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { shirtType: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            shirtType: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        shirtType: typeof args.shirtType === 'object'
        ? args.shirtType.id
        : args.shirtType,
    }

    return update.definition.url
            .replace('{shirtType}', parsedArgs.shirtType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShirtDataManagementController::update
* @see app/Http/Controllers/ShirtDataManagementController.php:73
* @route '/settings/data/shirts/types/{shirtType}'
*/
update.put = (args: { shirtType: number | { id: number } } | [shirtType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ShirtDataManagementController::update
* @see app/Http/Controllers/ShirtDataManagementController.php:73
* @route '/settings/data/shirts/types/{shirtType}'
*/
const updateForm = (args: { shirtType: number | { id: number } } | [shirtType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ShirtDataManagementController::update
* @see app/Http/Controllers/ShirtDataManagementController.php:73
* @route '/settings/data/shirts/types/{shirtType}'
*/
updateForm.put = (args: { shirtType: number | { id: number } } | [shirtType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\ShirtDataManagementController::destroy
* @see app/Http/Controllers/ShirtDataManagementController.php:86
* @route '/settings/data/shirts/types/{shirtType}'
*/
export const destroy = (args: { shirtType: number | { id: number } } | [shirtType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/settings/data/shirts/types/{shirtType}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ShirtDataManagementController::destroy
* @see app/Http/Controllers/ShirtDataManagementController.php:86
* @route '/settings/data/shirts/types/{shirtType}'
*/
destroy.url = (args: { shirtType: number | { id: number } } | [shirtType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { shirtType: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { shirtType: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            shirtType: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        shirtType: typeof args.shirtType === 'object'
        ? args.shirtType.id
        : args.shirtType,
    }

    return destroy.definition.url
            .replace('{shirtType}', parsedArgs.shirtType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShirtDataManagementController::destroy
* @see app/Http/Controllers/ShirtDataManagementController.php:86
* @route '/settings/data/shirts/types/{shirtType}'
*/
destroy.delete = (args: { shirtType: number | { id: number } } | [shirtType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ShirtDataManagementController::destroy
* @see app/Http/Controllers/ShirtDataManagementController.php:86
* @route '/settings/data/shirts/types/{shirtType}'
*/
const destroyForm = (args: { shirtType: number | { id: number } } | [shirtType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ShirtDataManagementController::destroy
* @see app/Http/Controllers/ShirtDataManagementController.php:86
* @route '/settings/data/shirts/types/{shirtType}'
*/
destroyForm.delete = (args: { shirtType: number | { id: number } } | [shirtType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const types = {
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default types