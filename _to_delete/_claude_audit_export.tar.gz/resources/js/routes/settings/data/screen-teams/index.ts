import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::index
* @see app/Http/Controllers/Settings/ScreenTeamController.php:15
* @route '/settings/data/screen-teams'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/settings/data/screen-teams',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::index
* @see app/Http/Controllers/Settings/ScreenTeamController.php:15
* @route '/settings/data/screen-teams'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::index
* @see app/Http/Controllers/Settings/ScreenTeamController.php:15
* @route '/settings/data/screen-teams'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::index
* @see app/Http/Controllers/Settings/ScreenTeamController.php:15
* @route '/settings/data/screen-teams'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::index
* @see app/Http/Controllers/Settings/ScreenTeamController.php:15
* @route '/settings/data/screen-teams'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::index
* @see app/Http/Controllers/Settings/ScreenTeamController.php:15
* @route '/settings/data/screen-teams'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::index
* @see app/Http/Controllers/Settings/ScreenTeamController.php:15
* @route '/settings/data/screen-teams'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::store
* @see app/Http/Controllers/Settings/ScreenTeamController.php:22
* @route '/settings/data/screen-teams'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/settings/data/screen-teams',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::store
* @see app/Http/Controllers/Settings/ScreenTeamController.php:22
* @route '/settings/data/screen-teams'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::store
* @see app/Http/Controllers/Settings/ScreenTeamController.php:22
* @route '/settings/data/screen-teams'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::store
* @see app/Http/Controllers/Settings/ScreenTeamController.php:22
* @route '/settings/data/screen-teams'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::store
* @see app/Http/Controllers/Settings/ScreenTeamController.php:22
* @route '/settings/data/screen-teams'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::update
* @see app/Http/Controllers/Settings/ScreenTeamController.php:39
* @route '/settings/data/screen-teams/{screenTeam}'
*/
export const update = (args: { screenTeam: number | { id: number } } | [screenTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/settings/data/screen-teams/{screenTeam}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::update
* @see app/Http/Controllers/Settings/ScreenTeamController.php:39
* @route '/settings/data/screen-teams/{screenTeam}'
*/
update.url = (args: { screenTeam: number | { id: number } } | [screenTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { screenTeam: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { screenTeam: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            screenTeam: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        screenTeam: typeof args.screenTeam === 'object'
        ? args.screenTeam.id
        : args.screenTeam,
    }

    return update.definition.url
            .replace('{screenTeam}', parsedArgs.screenTeam.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::update
* @see app/Http/Controllers/Settings/ScreenTeamController.php:39
* @route '/settings/data/screen-teams/{screenTeam}'
*/
update.put = (args: { screenTeam: number | { id: number } } | [screenTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::update
* @see app/Http/Controllers/Settings/ScreenTeamController.php:39
* @route '/settings/data/screen-teams/{screenTeam}'
*/
const updateForm = (args: { screenTeam: number | { id: number } } | [screenTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::update
* @see app/Http/Controllers/Settings/ScreenTeamController.php:39
* @route '/settings/data/screen-teams/{screenTeam}'
*/
updateForm.put = (args: { screenTeam: number | { id: number } } | [screenTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::destroy
* @see app/Http/Controllers/Settings/ScreenTeamController.php:61
* @route '/settings/data/screen-teams/{screenTeam}'
*/
export const destroy = (args: { screenTeam: number | { id: number } } | [screenTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/settings/data/screen-teams/{screenTeam}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::destroy
* @see app/Http/Controllers/Settings/ScreenTeamController.php:61
* @route '/settings/data/screen-teams/{screenTeam}'
*/
destroy.url = (args: { screenTeam: number | { id: number } } | [screenTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { screenTeam: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { screenTeam: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            screenTeam: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        screenTeam: typeof args.screenTeam === 'object'
        ? args.screenTeam.id
        : args.screenTeam,
    }

    return destroy.definition.url
            .replace('{screenTeam}', parsedArgs.screenTeam.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::destroy
* @see app/Http/Controllers/Settings/ScreenTeamController.php:61
* @route '/settings/data/screen-teams/{screenTeam}'
*/
destroy.delete = (args: { screenTeam: number | { id: number } } | [screenTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::destroy
* @see app/Http/Controllers/Settings/ScreenTeamController.php:61
* @route '/settings/data/screen-teams/{screenTeam}'
*/
const destroyForm = (args: { screenTeam: number | { id: number } } | [screenTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\ScreenTeamController::destroy
* @see app/Http/Controllers/Settings/ScreenTeamController.php:61
* @route '/settings/data/screen-teams/{screenTeam}'
*/
destroyForm.delete = (args: { screenTeam: number | { id: number } } | [screenTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const screenTeams = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default screenTeams