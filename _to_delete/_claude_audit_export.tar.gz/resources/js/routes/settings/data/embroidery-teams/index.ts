import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::index
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:15
* @route '/settings/data/embroidery-teams'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/settings/data/embroidery-teams',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::index
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:15
* @route '/settings/data/embroidery-teams'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::index
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:15
* @route '/settings/data/embroidery-teams'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::index
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:15
* @route '/settings/data/embroidery-teams'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::index
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:15
* @route '/settings/data/embroidery-teams'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::index
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:15
* @route '/settings/data/embroidery-teams'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::index
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:15
* @route '/settings/data/embroidery-teams'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::store
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:22
* @route '/settings/data/embroidery-teams'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/settings/data/embroidery-teams',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::store
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:22
* @route '/settings/data/embroidery-teams'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::store
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:22
* @route '/settings/data/embroidery-teams'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::store
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:22
* @route '/settings/data/embroidery-teams'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::store
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:22
* @route '/settings/data/embroidery-teams'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::update
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:37
* @route '/settings/data/embroidery-teams/{embroideryTeam}'
*/
export const update = (args: { embroideryTeam: number | { id: number } } | [embroideryTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/settings/data/embroidery-teams/{embroideryTeam}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::update
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:37
* @route '/settings/data/embroidery-teams/{embroideryTeam}'
*/
update.url = (args: { embroideryTeam: number | { id: number } } | [embroideryTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { embroideryTeam: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { embroideryTeam: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            embroideryTeam: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        embroideryTeam: typeof args.embroideryTeam === 'object'
        ? args.embroideryTeam.id
        : args.embroideryTeam,
    }

    return update.definition.url
            .replace('{embroideryTeam}', parsedArgs.embroideryTeam.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::update
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:37
* @route '/settings/data/embroidery-teams/{embroideryTeam}'
*/
update.put = (args: { embroideryTeam: number | { id: number } } | [embroideryTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::update
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:37
* @route '/settings/data/embroidery-teams/{embroideryTeam}'
*/
const updateForm = (args: { embroideryTeam: number | { id: number } } | [embroideryTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::update
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:37
* @route '/settings/data/embroidery-teams/{embroideryTeam}'
*/
updateForm.put = (args: { embroideryTeam: number | { id: number } } | [embroideryTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::destroy
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:57
* @route '/settings/data/embroidery-teams/{embroideryTeam}'
*/
export const destroy = (args: { embroideryTeam: number | { id: number } } | [embroideryTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/settings/data/embroidery-teams/{embroideryTeam}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::destroy
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:57
* @route '/settings/data/embroidery-teams/{embroideryTeam}'
*/
destroy.url = (args: { embroideryTeam: number | { id: number } } | [embroideryTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { embroideryTeam: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { embroideryTeam: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            embroideryTeam: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        embroideryTeam: typeof args.embroideryTeam === 'object'
        ? args.embroideryTeam.id
        : args.embroideryTeam,
    }

    return destroy.definition.url
            .replace('{embroideryTeam}', parsedArgs.embroideryTeam.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::destroy
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:57
* @route '/settings/data/embroidery-teams/{embroideryTeam}'
*/
destroy.delete = (args: { embroideryTeam: number | { id: number } } | [embroideryTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::destroy
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:57
* @route '/settings/data/embroidery-teams/{embroideryTeam}'
*/
const destroyForm = (args: { embroideryTeam: number | { id: number } } | [embroideryTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\EmbroideryTeamController::destroy
* @see app/Http/Controllers/Settings/EmbroideryTeamController.php:57
* @route '/settings/data/embroidery-teams/{embroideryTeam}'
*/
destroyForm.delete = (args: { embroideryTeam: number | { id: number } } | [embroideryTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const embroideryTeams = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default embroideryTeams