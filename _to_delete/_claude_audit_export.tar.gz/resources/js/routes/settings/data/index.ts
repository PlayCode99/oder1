import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import branches from './branches'
import jobTypes from './job-types'
import cuttingTeams from './cutting-teams'
import sewingTeams from './sewing-teams'
import embroideryTeams from './embroidery-teams'
import screenTeams from './screen-teams'
import heatPressMachines from './heat-press-machines'
import garments from './garments'
import shirts from './shirts'
import catalogItems from './catalog-items'
import pants from './pants'
/**
* @see \App\Http\Controllers\ShirtCatalogController::sizeKids
* @see app/Http/Controllers/ShirtCatalogController.php:146
* @route '/settings/data/size-kids'
*/
export const sizeKids = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sizeKids.url(options),
    method: 'get',
})

sizeKids.definition = {
    methods: ["get","head"],
    url: '/settings/data/size-kids',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShirtCatalogController::sizeKids
* @see app/Http/Controllers/ShirtCatalogController.php:146
* @route '/settings/data/size-kids'
*/
sizeKids.url = (options?: RouteQueryOptions) => {
    return sizeKids.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShirtCatalogController::sizeKids
* @see app/Http/Controllers/ShirtCatalogController.php:146
* @route '/settings/data/size-kids'
*/
sizeKids.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sizeKids.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::sizeKids
* @see app/Http/Controllers/ShirtCatalogController.php:146
* @route '/settings/data/size-kids'
*/
sizeKids.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sizeKids.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::sizeKids
* @see app/Http/Controllers/ShirtCatalogController.php:146
* @route '/settings/data/size-kids'
*/
const sizeKidsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sizeKids.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::sizeKids
* @see app/Http/Controllers/ShirtCatalogController.php:146
* @route '/settings/data/size-kids'
*/
sizeKidsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sizeKids.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::sizeKids
* @see app/Http/Controllers/ShirtCatalogController.php:146
* @route '/settings/data/size-kids'
*/
sizeKidsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sizeKids.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

sizeKids.form = sizeKidsForm

/**
* @see \App\Http\Controllers\ShirtCatalogController::sizeAdults
* @see app/Http/Controllers/ShirtCatalogController.php:159
* @route '/settings/data/size-adults'
*/
export const sizeAdults = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sizeAdults.url(options),
    method: 'get',
})

sizeAdults.definition = {
    methods: ["get","head"],
    url: '/settings/data/size-adults',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShirtCatalogController::sizeAdults
* @see app/Http/Controllers/ShirtCatalogController.php:159
* @route '/settings/data/size-adults'
*/
sizeAdults.url = (options?: RouteQueryOptions) => {
    return sizeAdults.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShirtCatalogController::sizeAdults
* @see app/Http/Controllers/ShirtCatalogController.php:159
* @route '/settings/data/size-adults'
*/
sizeAdults.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sizeAdults.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::sizeAdults
* @see app/Http/Controllers/ShirtCatalogController.php:159
* @route '/settings/data/size-adults'
*/
sizeAdults.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sizeAdults.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::sizeAdults
* @see app/Http/Controllers/ShirtCatalogController.php:159
* @route '/settings/data/size-adults'
*/
const sizeAdultsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sizeAdults.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::sizeAdults
* @see app/Http/Controllers/ShirtCatalogController.php:159
* @route '/settings/data/size-adults'
*/
sizeAdultsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sizeAdults.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ShirtCatalogController::sizeAdults
* @see app/Http/Controllers/ShirtCatalogController.php:159
* @route '/settings/data/size-adults'
*/
sizeAdultsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sizeAdults.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

sizeAdults.form = sizeAdultsForm

const data = {
    branches: Object.assign(branches, branches),
    jobTypes: Object.assign(jobTypes, jobTypes),
    cuttingTeams: Object.assign(cuttingTeams, cuttingTeams),
    sewingTeams: Object.assign(sewingTeams, sewingTeams),
    embroideryTeams: Object.assign(embroideryTeams, embroideryTeams),
    screenTeams: Object.assign(screenTeams, screenTeams),
    heatPressMachines: Object.assign(heatPressMachines, heatPressMachines),
    garments: Object.assign(garments, garments),
    shirts: Object.assign(shirts, shirts),
    catalogItems: Object.assign(catalogItems, catalogItems),
    pants: Object.assign(pants, pants),
    sizeKids: Object.assign(sizeKids, sizeKids),
    sizeAdults: Object.assign(sizeAdults, sizeAdults),
}

export default data