import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
import types907509 from './types'
import prices56fd13 from './prices'
/**
* @see \App\Http\Controllers\GarmentPricingController::types
* @see app/Http/Controllers/GarmentPricingController.php:24
* @route '/settings/data/garments/types'
*/
export const types = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: types.url(options),
    method: 'get',
})

types.definition = {
    methods: ["get","head"],
    url: '/settings/data/garments/types',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GarmentPricingController::types
* @see app/Http/Controllers/GarmentPricingController.php:24
* @route '/settings/data/garments/types'
*/
types.url = (options?: RouteQueryOptions) => {
    return types.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GarmentPricingController::types
* @see app/Http/Controllers/GarmentPricingController.php:24
* @route '/settings/data/garments/types'
*/
types.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: types.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GarmentPricingController::types
* @see app/Http/Controllers/GarmentPricingController.php:24
* @route '/settings/data/garments/types'
*/
types.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: types.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GarmentPricingController::types
* @see app/Http/Controllers/GarmentPricingController.php:24
* @route '/settings/data/garments/types'
*/
const typesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: types.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GarmentPricingController::types
* @see app/Http/Controllers/GarmentPricingController.php:24
* @route '/settings/data/garments/types'
*/
typesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: types.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GarmentPricingController::types
* @see app/Http/Controllers/GarmentPricingController.php:24
* @route '/settings/data/garments/types'
*/
typesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: types.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

types.form = typesForm

/**
* @see \App\Http\Controllers\GarmentPricingController::prices
* @see app/Http/Controllers/GarmentPricingController.php:34
* @route '/settings/data/garments/prices'
*/
export const prices = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: prices.url(options),
    method: 'get',
})

prices.definition = {
    methods: ["get","head"],
    url: '/settings/data/garments/prices',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GarmentPricingController::prices
* @see app/Http/Controllers/GarmentPricingController.php:34
* @route '/settings/data/garments/prices'
*/
prices.url = (options?: RouteQueryOptions) => {
    return prices.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GarmentPricingController::prices
* @see app/Http/Controllers/GarmentPricingController.php:34
* @route '/settings/data/garments/prices'
*/
prices.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: prices.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GarmentPricingController::prices
* @see app/Http/Controllers/GarmentPricingController.php:34
* @route '/settings/data/garments/prices'
*/
prices.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: prices.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GarmentPricingController::prices
* @see app/Http/Controllers/GarmentPricingController.php:34
* @route '/settings/data/garments/prices'
*/
const pricesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: prices.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GarmentPricingController::prices
* @see app/Http/Controllers/GarmentPricingController.php:34
* @route '/settings/data/garments/prices'
*/
pricesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: prices.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GarmentPricingController::prices
* @see app/Http/Controllers/GarmentPricingController.php:34
* @route '/settings/data/garments/prices'
*/
pricesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: prices.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

prices.form = pricesForm

const garments = {
    types: Object.assign(types, types907509),
    prices: Object.assign(prices, prices56fd13),
}

export default garments