import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\GarmentPricingController::store
* @see app/Http/Controllers/GarmentPricingController.php:99
* @route '/settings/data/garments/prices'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/settings/data/garments/prices',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\GarmentPricingController::store
* @see app/Http/Controllers/GarmentPricingController.php:99
* @route '/settings/data/garments/prices'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GarmentPricingController::store
* @see app/Http/Controllers/GarmentPricingController.php:99
* @route '/settings/data/garments/prices'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\GarmentPricingController::store
* @see app/Http/Controllers/GarmentPricingController.php:99
* @route '/settings/data/garments/prices'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\GarmentPricingController::store
* @see app/Http/Controllers/GarmentPricingController.php:99
* @route '/settings/data/garments/prices'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\GarmentPricingController::update
* @see app/Http/Controllers/GarmentPricingController.php:111
* @route '/settings/data/garments/prices/{garmentOperation}'
*/
export const update = (args: { garmentOperation: number | { id: number } } | [garmentOperation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/settings/data/garments/prices/{garmentOperation}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\GarmentPricingController::update
* @see app/Http/Controllers/GarmentPricingController.php:111
* @route '/settings/data/garments/prices/{garmentOperation}'
*/
update.url = (args: { garmentOperation: number | { id: number } } | [garmentOperation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { garmentOperation: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { garmentOperation: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            garmentOperation: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        garmentOperation: typeof args.garmentOperation === 'object'
        ? args.garmentOperation.id
        : args.garmentOperation,
    }

    return update.definition.url
            .replace('{garmentOperation}', parsedArgs.garmentOperation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GarmentPricingController::update
* @see app/Http/Controllers/GarmentPricingController.php:111
* @route '/settings/data/garments/prices/{garmentOperation}'
*/
update.put = (args: { garmentOperation: number | { id: number } } | [garmentOperation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\GarmentPricingController::update
* @see app/Http/Controllers/GarmentPricingController.php:111
* @route '/settings/data/garments/prices/{garmentOperation}'
*/
const updateForm = (args: { garmentOperation: number | { id: number } } | [garmentOperation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\GarmentPricingController::update
* @see app/Http/Controllers/GarmentPricingController.php:111
* @route '/settings/data/garments/prices/{garmentOperation}'
*/
updateForm.put = (args: { garmentOperation: number | { id: number } } | [garmentOperation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\GarmentPricingController::destroy
* @see app/Http/Controllers/GarmentPricingController.php:124
* @route '/settings/data/garments/prices/{garmentOperation}'
*/
export const destroy = (args: { garmentOperation: number | { id: number } } | [garmentOperation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/settings/data/garments/prices/{garmentOperation}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\GarmentPricingController::destroy
* @see app/Http/Controllers/GarmentPricingController.php:124
* @route '/settings/data/garments/prices/{garmentOperation}'
*/
destroy.url = (args: { garmentOperation: number | { id: number } } | [garmentOperation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { garmentOperation: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { garmentOperation: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            garmentOperation: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        garmentOperation: typeof args.garmentOperation === 'object'
        ? args.garmentOperation.id
        : args.garmentOperation,
    }

    return destroy.definition.url
            .replace('{garmentOperation}', parsedArgs.garmentOperation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\GarmentPricingController::destroy
* @see app/Http/Controllers/GarmentPricingController.php:124
* @route '/settings/data/garments/prices/{garmentOperation}'
*/
destroy.delete = (args: { garmentOperation: number | { id: number } } | [garmentOperation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\GarmentPricingController::destroy
* @see app/Http/Controllers/GarmentPricingController.php:124
* @route '/settings/data/garments/prices/{garmentOperation}'
*/
const destroyForm = (args: { garmentOperation: number | { id: number } } | [garmentOperation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\GarmentPricingController::destroy
* @see app/Http/Controllers/GarmentPricingController.php:124
* @route '/settings/data/garments/prices/{garmentOperation}'
*/
destroyForm.delete = (args: { garmentOperation: number | { id: number } } | [garmentOperation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const prices = {
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default prices