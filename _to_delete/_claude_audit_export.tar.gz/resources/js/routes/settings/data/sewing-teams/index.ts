import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\SewingTeamController::index
* @see app/Http/Controllers/Settings/SewingTeamController.php:15
* @route '/settings/data/sewing-teams'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/settings/data/sewing-teams',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::index
* @see app/Http/Controllers/Settings/SewingTeamController.php:15
* @route '/settings/data/sewing-teams'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::index
* @see app/Http/Controllers/Settings/SewingTeamController.php:15
* @route '/settings/data/sewing-teams'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::index
* @see app/Http/Controllers/Settings/SewingTeamController.php:15
* @route '/settings/data/sewing-teams'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::index
* @see app/Http/Controllers/Settings/SewingTeamController.php:15
* @route '/settings/data/sewing-teams'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::index
* @see app/Http/Controllers/Settings/SewingTeamController.php:15
* @route '/settings/data/sewing-teams'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::index
* @see app/Http/Controllers/Settings/SewingTeamController.php:15
* @route '/settings/data/sewing-teams'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::store
* @see app/Http/Controllers/Settings/SewingTeamController.php:22
* @route '/settings/data/sewing-teams'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/settings/data/sewing-teams',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::store
* @see app/Http/Controllers/Settings/SewingTeamController.php:22
* @route '/settings/data/sewing-teams'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::store
* @see app/Http/Controllers/Settings/SewingTeamController.php:22
* @route '/settings/data/sewing-teams'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::store
* @see app/Http/Controllers/Settings/SewingTeamController.php:22
* @route '/settings/data/sewing-teams'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::store
* @see app/Http/Controllers/Settings/SewingTeamController.php:22
* @route '/settings/data/sewing-teams'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::update
* @see app/Http/Controllers/Settings/SewingTeamController.php:37
* @route '/settings/data/sewing-teams/{sewingTeam}'
*/
export const update = (args: { sewingTeam: number | { id: number } } | [sewingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/settings/data/sewing-teams/{sewingTeam}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::update
* @see app/Http/Controllers/Settings/SewingTeamController.php:37
* @route '/settings/data/sewing-teams/{sewingTeam}'
*/
update.url = (args: { sewingTeam: number | { id: number } } | [sewingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sewingTeam: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { sewingTeam: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            sewingTeam: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        sewingTeam: typeof args.sewingTeam === 'object'
        ? args.sewingTeam.id
        : args.sewingTeam,
    }

    return update.definition.url
            .replace('{sewingTeam}', parsedArgs.sewingTeam.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::update
* @see app/Http/Controllers/Settings/SewingTeamController.php:37
* @route '/settings/data/sewing-teams/{sewingTeam}'
*/
update.put = (args: { sewingTeam: number | { id: number } } | [sewingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::update
* @see app/Http/Controllers/Settings/SewingTeamController.php:37
* @route '/settings/data/sewing-teams/{sewingTeam}'
*/
const updateForm = (args: { sewingTeam: number | { id: number } } | [sewingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::update
* @see app/Http/Controllers/Settings/SewingTeamController.php:37
* @route '/settings/data/sewing-teams/{sewingTeam}'
*/
updateForm.put = (args: { sewingTeam: number | { id: number } } | [sewingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::destroy
* @see app/Http/Controllers/Settings/SewingTeamController.php:57
* @route '/settings/data/sewing-teams/{sewingTeam}'
*/
export const destroy = (args: { sewingTeam: number | { id: number } } | [sewingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/settings/data/sewing-teams/{sewingTeam}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::destroy
* @see app/Http/Controllers/Settings/SewingTeamController.php:57
* @route '/settings/data/sewing-teams/{sewingTeam}'
*/
destroy.url = (args: { sewingTeam: number | { id: number } } | [sewingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sewingTeam: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { sewingTeam: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            sewingTeam: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        sewingTeam: typeof args.sewingTeam === 'object'
        ? args.sewingTeam.id
        : args.sewingTeam,
    }

    return destroy.definition.url
            .replace('{sewingTeam}', parsedArgs.sewingTeam.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::destroy
* @see app/Http/Controllers/Settings/SewingTeamController.php:57
* @route '/settings/data/sewing-teams/{sewingTeam}'
*/
destroy.delete = (args: { sewingTeam: number | { id: number } } | [sewingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::destroy
* @see app/Http/Controllers/Settings/SewingTeamController.php:57
* @route '/settings/data/sewing-teams/{sewingTeam}'
*/
const destroyForm = (args: { sewingTeam: number | { id: number } } | [sewingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\SewingTeamController::destroy
* @see app/Http/Controllers/Settings/SewingTeamController.php:57
* @route '/settings/data/sewing-teams/{sewingTeam}'
*/
destroyForm.delete = (args: { sewingTeam: number | { id: number } } | [sewingTeam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const sewingTeams = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default sewingTeams