import deliveryInfo from './delivery-info'

const shipping = {
    deliveryInfo: Object.assign(deliveryInfo, deliveryInfo),
}

export default shipping