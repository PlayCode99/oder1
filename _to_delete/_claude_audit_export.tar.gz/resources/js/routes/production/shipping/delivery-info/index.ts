import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Production\ProductionRoutingController::store
* @see app/Http/Controllers/Production/ProductionRoutingController.php:68
* @route '/orders/{order}/shipping-delivery-info'
*/
export const store = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/orders/{order}/shipping-delivery-info',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Production\ProductionRoutingController::store
* @see app/Http/Controllers/Production/ProductionRoutingController.php:68
* @route '/orders/{order}/shipping-delivery-info'
*/
store.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { order: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: typeof args.order === 'object'
        ? args.order.id
        : args.order,
    }

    return store.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Production\ProductionRoutingController::store
* @see app/Http/Controllers/Production/ProductionRoutingController.php:68
* @route '/orders/{order}/shipping-delivery-info'
*/
store.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Production\ProductionRoutingController::store
* @see app/Http/Controllers/Production/ProductionRoutingController.php:68
* @route '/orders/{order}/shipping-delivery-info'
*/
const storeForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Production\ProductionRoutingController::store
* @see app/Http/Controllers/Production/ProductionRoutingController.php:68
* @route '/orders/{order}/shipping-delivery-info'
*/
storeForm.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

const deliveryInfo = {
    store: Object.assign(store, store),
}

export default deliveryInfo