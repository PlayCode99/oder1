import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Production\CuttingTaskController::store
* @see app/Http/Controllers/Production/CuttingTaskController.php:14
* @route '/production/cutting-tasks'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/production/cutting-tasks',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Production\CuttingTaskController::store
* @see app/Http/Controllers/Production/CuttingTaskController.php:14
* @route '/production/cutting-tasks'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Production\CuttingTaskController::store
* @see app/Http/Controllers/Production/CuttingTaskController.php:14
* @route '/production/cutting-tasks'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Production\CuttingTaskController::store
* @see app/Http/Controllers/Production/CuttingTaskController.php:14
* @route '/production/cutting-tasks'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Production\CuttingTaskController::store
* @see app/Http/Controllers/Production/CuttingTaskController.php:14
* @route '/production/cutting-tasks'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const cuttingTasks = {
    store: Object.assign(store, store),
}

export default cuttingTasks