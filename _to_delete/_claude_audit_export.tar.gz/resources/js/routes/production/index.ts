import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import shipping7a8d3c from './shipping'
import routing from './routing'
import cuttingTasks from './cutting-tasks'
/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::kanban
* @see app/Http/Controllers/Production/ProductionKanbanController.php:537
* @route '/production/kanban'
*/
export const kanban = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: kanban.url(options),
    method: 'get',
})

kanban.definition = {
    methods: ["get","head"],
    url: '/production/kanban',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::kanban
* @see app/Http/Controllers/Production/ProductionKanbanController.php:537
* @route '/production/kanban'
*/
kanban.url = (options?: RouteQueryOptions) => {
    return kanban.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::kanban
* @see app/Http/Controllers/Production/ProductionKanbanController.php:537
* @route '/production/kanban'
*/
kanban.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: kanban.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::kanban
* @see app/Http/Controllers/Production/ProductionKanbanController.php:537
* @route '/production/kanban'
*/
kanban.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: kanban.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::kanban
* @see app/Http/Controllers/Production/ProductionKanbanController.php:537
* @route '/production/kanban'
*/
const kanbanForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: kanban.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::kanban
* @see app/Http/Controllers/Production/ProductionKanbanController.php:537
* @route '/production/kanban'
*/
kanbanForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: kanban.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::kanban
* @see app/Http/Controllers/Production/ProductionKanbanController.php:537
* @route '/production/kanban'
*/
kanbanForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: kanban.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

kanban.form = kanbanForm

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::printRoom
* @see app/Http/Controllers/Production/ProductionKanbanController.php:544
* @route '/production/print-room'
*/
export const printRoom = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printRoom.url(options),
    method: 'get',
})

printRoom.definition = {
    methods: ["get","head"],
    url: '/production/print-room',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::printRoom
* @see app/Http/Controllers/Production/ProductionKanbanController.php:544
* @route '/production/print-room'
*/
printRoom.url = (options?: RouteQueryOptions) => {
    return printRoom.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::printRoom
* @see app/Http/Controllers/Production/ProductionKanbanController.php:544
* @route '/production/print-room'
*/
printRoom.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printRoom.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::printRoom
* @see app/Http/Controllers/Production/ProductionKanbanController.php:544
* @route '/production/print-room'
*/
printRoom.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: printRoom.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::printRoom
* @see app/Http/Controllers/Production/ProductionKanbanController.php:544
* @route '/production/print-room'
*/
const printRoomForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printRoom.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::printRoom
* @see app/Http/Controllers/Production/ProductionKanbanController.php:544
* @route '/production/print-room'
*/
printRoomForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printRoom.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::printRoom
* @see app/Http/Controllers/Production/ProductionKanbanController.php:544
* @route '/production/print-room'
*/
printRoomForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printRoom.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

printRoom.form = printRoomForm

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::heatPress
* @see app/Http/Controllers/Production/ProductionKanbanController.php:549
* @route '/production/heat-press'
*/
export const heatPress = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: heatPress.url(options),
    method: 'get',
})

heatPress.definition = {
    methods: ["get","head"],
    url: '/production/heat-press',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::heatPress
* @see app/Http/Controllers/Production/ProductionKanbanController.php:549
* @route '/production/heat-press'
*/
heatPress.url = (options?: RouteQueryOptions) => {
    return heatPress.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::heatPress
* @see app/Http/Controllers/Production/ProductionKanbanController.php:549
* @route '/production/heat-press'
*/
heatPress.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: heatPress.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::heatPress
* @see app/Http/Controllers/Production/ProductionKanbanController.php:549
* @route '/production/heat-press'
*/
heatPress.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: heatPress.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::heatPress
* @see app/Http/Controllers/Production/ProductionKanbanController.php:549
* @route '/production/heat-press'
*/
const heatPressForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: heatPress.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::heatPress
* @see app/Http/Controllers/Production/ProductionKanbanController.php:549
* @route '/production/heat-press'
*/
heatPressForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: heatPress.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::heatPress
* @see app/Http/Controllers/Production/ProductionKanbanController.php:549
* @route '/production/heat-press'
*/
heatPressForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: heatPress.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

heatPress.form = heatPressForm

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::embroidery
* @see app/Http/Controllers/Production/ProductionKanbanController.php:554
* @route '/production/embroidery'
*/
export const embroidery = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: embroidery.url(options),
    method: 'get',
})

embroidery.definition = {
    methods: ["get","head"],
    url: '/production/embroidery',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::embroidery
* @see app/Http/Controllers/Production/ProductionKanbanController.php:554
* @route '/production/embroidery'
*/
embroidery.url = (options?: RouteQueryOptions) => {
    return embroidery.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::embroidery
* @see app/Http/Controllers/Production/ProductionKanbanController.php:554
* @route '/production/embroidery'
*/
embroidery.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: embroidery.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::embroidery
* @see app/Http/Controllers/Production/ProductionKanbanController.php:554
* @route '/production/embroidery'
*/
embroidery.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: embroidery.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::embroidery
* @see app/Http/Controllers/Production/ProductionKanbanController.php:554
* @route '/production/embroidery'
*/
const embroideryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: embroidery.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::embroidery
* @see app/Http/Controllers/Production/ProductionKanbanController.php:554
* @route '/production/embroidery'
*/
embroideryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: embroidery.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::embroidery
* @see app/Http/Controllers/Production/ProductionKanbanController.php:554
* @route '/production/embroidery'
*/
embroideryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: embroidery.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

embroidery.form = embroideryForm

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::cutting
* @see app/Http/Controllers/Production/ProductionKanbanController.php:559
* @route '/production/cutting'
*/
export const cutting = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cutting.url(options),
    method: 'get',
})

cutting.definition = {
    methods: ["get","head"],
    url: '/production/cutting',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::cutting
* @see app/Http/Controllers/Production/ProductionKanbanController.php:559
* @route '/production/cutting'
*/
cutting.url = (options?: RouteQueryOptions) => {
    return cutting.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::cutting
* @see app/Http/Controllers/Production/ProductionKanbanController.php:559
* @route '/production/cutting'
*/
cutting.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cutting.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::cutting
* @see app/Http/Controllers/Production/ProductionKanbanController.php:559
* @route '/production/cutting'
*/
cutting.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: cutting.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::cutting
* @see app/Http/Controllers/Production/ProductionKanbanController.php:559
* @route '/production/cutting'
*/
const cuttingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cutting.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::cutting
* @see app/Http/Controllers/Production/ProductionKanbanController.php:559
* @route '/production/cutting'
*/
cuttingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cutting.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::cutting
* @see app/Http/Controllers/Production/ProductionKanbanController.php:559
* @route '/production/cutting'
*/
cuttingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cutting.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

cutting.form = cuttingForm

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::sewing
* @see app/Http/Controllers/Production/ProductionKanbanController.php:564
* @route '/production/sewing'
*/
export const sewing = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sewing.url(options),
    method: 'get',
})

sewing.definition = {
    methods: ["get","head"],
    url: '/production/sewing',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::sewing
* @see app/Http/Controllers/Production/ProductionKanbanController.php:564
* @route '/production/sewing'
*/
sewing.url = (options?: RouteQueryOptions) => {
    return sewing.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::sewing
* @see app/Http/Controllers/Production/ProductionKanbanController.php:564
* @route '/production/sewing'
*/
sewing.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sewing.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::sewing
* @see app/Http/Controllers/Production/ProductionKanbanController.php:564
* @route '/production/sewing'
*/
sewing.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sewing.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::sewing
* @see app/Http/Controllers/Production/ProductionKanbanController.php:564
* @route '/production/sewing'
*/
const sewingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sewing.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::sewing
* @see app/Http/Controllers/Production/ProductionKanbanController.php:564
* @route '/production/sewing'
*/
sewingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sewing.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::sewing
* @see app/Http/Controllers/Production/ProductionKanbanController.php:564
* @route '/production/sewing'
*/
sewingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sewing.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

sewing.form = sewingForm

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::screenFlex
* @see app/Http/Controllers/Production/ProductionKanbanController.php:569
* @route '/production/screen-flex'
*/
export const screenFlex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: screenFlex.url(options),
    method: 'get',
})

screenFlex.definition = {
    methods: ["get","head"],
    url: '/production/screen-flex',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::screenFlex
* @see app/Http/Controllers/Production/ProductionKanbanController.php:569
* @route '/production/screen-flex'
*/
screenFlex.url = (options?: RouteQueryOptions) => {
    return screenFlex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::screenFlex
* @see app/Http/Controllers/Production/ProductionKanbanController.php:569
* @route '/production/screen-flex'
*/
screenFlex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: screenFlex.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::screenFlex
* @see app/Http/Controllers/Production/ProductionKanbanController.php:569
* @route '/production/screen-flex'
*/
screenFlex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: screenFlex.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::screenFlex
* @see app/Http/Controllers/Production/ProductionKanbanController.php:569
* @route '/production/screen-flex'
*/
const screenFlexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: screenFlex.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::screenFlex
* @see app/Http/Controllers/Production/ProductionKanbanController.php:569
* @route '/production/screen-flex'
*/
screenFlexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: screenFlex.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::screenFlex
* @see app/Http/Controllers/Production/ProductionKanbanController.php:569
* @route '/production/screen-flex'
*/
screenFlexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: screenFlex.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

screenFlex.form = screenFlexForm

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::qc
* @see app/Http/Controllers/Production/ProductionKanbanController.php:574
* @route '/production/qc'
*/
export const qc = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qc.url(options),
    method: 'get',
})

qc.definition = {
    methods: ["get","head"],
    url: '/production/qc',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::qc
* @see app/Http/Controllers/Production/ProductionKanbanController.php:574
* @route '/production/qc'
*/
qc.url = (options?: RouteQueryOptions) => {
    return qc.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::qc
* @see app/Http/Controllers/Production/ProductionKanbanController.php:574
* @route '/production/qc'
*/
qc.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qc.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::qc
* @see app/Http/Controllers/Production/ProductionKanbanController.php:574
* @route '/production/qc'
*/
qc.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: qc.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::qc
* @see app/Http/Controllers/Production/ProductionKanbanController.php:574
* @route '/production/qc'
*/
const qcForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qc.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::qc
* @see app/Http/Controllers/Production/ProductionKanbanController.php:574
* @route '/production/qc'
*/
qcForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qc.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::qc
* @see app/Http/Controllers/Production/ProductionKanbanController.php:574
* @route '/production/qc'
*/
qcForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qc.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

qc.form = qcForm

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::shipping
* @see app/Http/Controllers/Production/ProductionKanbanController.php:579
* @route '/production/shipping'
*/
export const shipping = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: shipping.url(options),
    method: 'get',
})

shipping.definition = {
    methods: ["get","head"],
    url: '/production/shipping',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::shipping
* @see app/Http/Controllers/Production/ProductionKanbanController.php:579
* @route '/production/shipping'
*/
shipping.url = (options?: RouteQueryOptions) => {
    return shipping.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::shipping
* @see app/Http/Controllers/Production/ProductionKanbanController.php:579
* @route '/production/shipping'
*/
shipping.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: shipping.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::shipping
* @see app/Http/Controllers/Production/ProductionKanbanController.php:579
* @route '/production/shipping'
*/
shipping.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: shipping.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::shipping
* @see app/Http/Controllers/Production/ProductionKanbanController.php:579
* @route '/production/shipping'
*/
const shippingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: shipping.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::shipping
* @see app/Http/Controllers/Production/ProductionKanbanController.php:579
* @route '/production/shipping'
*/
shippingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: shipping.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Production\ProductionKanbanController::shipping
* @see app/Http/Controllers/Production/ProductionKanbanController.php:579
* @route '/production/shipping'
*/
shippingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: shipping.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

shipping.form = shippingForm

const production = {
    kanban: Object.assign(kanban, kanban),
    printRoom: Object.assign(printRoom, printRoom),
    heatPress: Object.assign(heatPress, heatPress),
    embroidery: Object.assign(embroidery, embroidery),
    cutting: Object.assign(cutting, cutting),
    sewing: Object.assign(sewing, sewing),
    screenFlex: Object.assign(screenFlex, screenFlex),
    qc: Object.assign(qc, qc),
    shipping: Object.assign(shipping, shipping7a8d3c),
    routing: Object.assign(routing, routing),
    cuttingTasks: Object.assign(cuttingTasks, cuttingTasks),
}

export default production