import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Production\ProductionRoutingController::advance
* @see app/Http/Controllers/Production/ProductionRoutingController.php:36
* @route '/orders/{order}/routing/advance'
*/
export const advance = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: advance.url(args, options),
    method: 'post',
})

advance.definition = {
    methods: ["post"],
    url: '/orders/{order}/routing/advance',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Production\ProductionRoutingController::advance
* @see app/Http/Controllers/Production/ProductionRoutingController.php:36
* @route '/orders/{order}/routing/advance'
*/
advance.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { order: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: typeof args.order === 'object'
        ? args.order.id
        : args.order,
    }

    return advance.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Production\ProductionRoutingController::advance
* @see app/Http/Controllers/Production/ProductionRoutingController.php:36
* @route '/orders/{order}/routing/advance'
*/
advance.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: advance.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Production\ProductionRoutingController::advance
* @see app/Http/Controllers/Production/ProductionRoutingController.php:36
* @route '/orders/{order}/routing/advance'
*/
const advanceForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: advance.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Production\ProductionRoutingController::advance
* @see app/Http/Controllers/Production/ProductionRoutingController.php:36
* @route '/orders/{order}/routing/advance'
*/
advanceForm.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: advance.url(args, options),
    method: 'post',
})

advance.form = advanceForm

const routing = {
    advance: Object.assign(advance, advance),
}

export default routing