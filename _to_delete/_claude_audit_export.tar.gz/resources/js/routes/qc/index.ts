import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\QcInspectionController::submit
* @see app/Http/Controllers/QcInspectionController.php:15
* @route '/orders/{order}/qc'
*/
export const submit = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/orders/{order}/qc',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\QcInspectionController::submit
* @see app/Http/Controllers/QcInspectionController.php:15
* @route '/orders/{order}/qc'
*/
submit.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { order: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: typeof args.order === 'object'
        ? args.order.id
        : args.order,
    }

    return submit.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\QcInspectionController::submit
* @see app/Http/Controllers/QcInspectionController.php:15
* @route '/orders/{order}/qc'
*/
submit.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QcInspectionController::submit
* @see app/Http/Controllers/QcInspectionController.php:15
* @route '/orders/{order}/qc'
*/
const submitForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QcInspectionController::submit
* @see app/Http/Controllers/QcInspectionController.php:15
* @route '/orders/{order}/qc'
*/
submitForm.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit.url(args, options),
    method: 'post',
})

submit.form = submitForm

const qc = {
    submit: Object.assign(submit, submit),
}

export default qc